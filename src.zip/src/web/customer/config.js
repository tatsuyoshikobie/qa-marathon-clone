const config = {
  apiUrl: 'http://localhost:4798'
};

export default config;